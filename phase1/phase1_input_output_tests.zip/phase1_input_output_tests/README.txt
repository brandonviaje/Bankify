Banking System — Phase 1 Test Inputs/Expected Outputs

- fixtures/current_accounts_base.txt
- tests/** : <TEST_ID>_input.txt + <TEST_ID>_expected_output.txt for:
  FE_01..FE_35, FE-G01..FE-G05, FE-TF01..FE-TF05, FE-CB01..FE-CB05
